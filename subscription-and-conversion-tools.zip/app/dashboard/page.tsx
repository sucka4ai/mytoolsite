import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { FileText, Zap, ArrowRight, Settings } from "lucide-react"
import { createPortalSession } from "@/app/actions/stripe"

export default async function DashboardPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const { data: subscription } = await supabase.from("subscriptions").select("*").eq("user_id", user.id).single()

  const isPremium = subscription?.plan_type === "premium"

  // Get conversion count
  const { count: conversionCount } = await supabase
    .from("conversion_history")
    .select("*", { count: "exact", head: true })
    .eq("user_id", user.id)

  // Get today's conversion count
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const { count: todayCount } = await supabase
    .from("conversion_history")
    .select("*", { count: "exact", head: true })
    .eq("user_id", user.id)
    .gte("created_at", today.toISOString())

  const handleSignOut = async () => {
    "use server"
    const supabase = await createClient()
    await supabase.auth.signOut()
    redirect("/")
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Zap className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">ConvertPro</span>
          </Link>
          <nav className="flex items-center gap-4">
            <Link href="/tools">
              <Button variant="ghost">Tools</Button>
            </Link>
            <form action={handleSignOut}>
              <Button variant="ghost" type="submit">
                Sign Out
              </Button>
            </form>
          </nav>
        </div>
      </header>

      <main className="container py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Welcome back, {profile?.full_name || user.email}!</h1>
          <p className="text-muted-foreground">Manage your account and view your conversion statistics</p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Current Plan</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{isPremium ? "Premium" : "Free"}</p>
              {isPremium ? (
                <form action={createPortalSession} className="mt-4">
                  <Button variant="outline" className="w-full gap-2 bg-transparent" type="submit">
                    <Settings className="h-4 w-4" />
                    Manage Subscription
                  </Button>
                </form>
              ) : (
                <Link href="/pricing" className="mt-4 block">
                  <Button className="w-full gap-2">
                    Upgrade Now
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Total Conversions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{conversionCount || 0}</p>
              <p className="text-sm text-muted-foreground">All time</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Today's Conversions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">
                {todayCount || 0}
                {!isPremium && " / 5"}
              </p>
              <p className="text-sm text-muted-foreground">{isPremium ? "Unlimited" : "Free plan limit"}</p>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Get started with file conversion</CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/tools">
              <Button size="lg" className="gap-2">
                <FileText className="h-5 w-5" />
                Start Converting Files
              </Button>
            </Link>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
