import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { SUBSCRIPTION_PLANS } from "@/lib/products"
import { ArrowRight, Check, FileImage, FileText, Video, Zap } from "lucide-react"
import Link from "next/link"
import { AdBanner } from "@/components/ad-banner"

export default function Page() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">ConvertPro</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/tools">
              <Button variant="ghost">Tools</Button>
            </Link>
            <Link href="#pricing">
              <Button variant="ghost">Pricing</Button>
            </Link>
            <Link href="/auth/login">
              <Button variant="ghost">Login</Button>
            </Link>
            <Link href="/auth/sign-up">
              <Button>Get Started</Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="container flex flex-col items-center gap-8 py-24 text-center md:py-32">
          <div className="inline-flex items-center gap-2 rounded-full border bg-muted px-4 py-1.5 text-sm">
            <Zap className="h-4 w-4" />
            <span>Fast, secure, and reliable file conversion</span>
          </div>
          <h1 className="max-w-4xl text-balance text-4xl font-bold leading-tight tracking-tight md:text-6xl lg:text-7xl">
            Convert Any File Format in Seconds
          </h1>
          <p className="max-w-2xl text-balance text-lg text-muted-foreground md:text-xl">
            Professional file conversion tools for documents, images, audio, and video. No software installation
            required. Convert files directly in your browser.
          </p>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Link href="/auth/sign-up">
              <Button size="lg" className="gap-2">
                Start Converting Free
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="#pricing">
              <Button size="lg" variant="outline">
                View Pricing
              </Button>
            </Link>
          </div>
        </section>

        {/* Features Section */}
        <section className="border-y bg-muted/30 py-16">
          <div className="container">
            <h2 className="mb-12 text-center text-3xl font-bold">Supported File Types</h2>
            <div className="grid gap-6 md:grid-cols-3">
              <Card>
                <CardHeader>
                  <FileText className="mb-2 h-10 w-10 text-primary" />
                  <CardTitle>Documents</CardTitle>
                  <CardDescription>PDF, DOCX, TXT, ODT, RTF</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Convert between popular document formats with perfect formatting preservation.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <FileImage className="mb-2 h-10 w-10 text-primary" />
                  <CardTitle>Images</CardTitle>
                  <CardDescription>JPG, PNG, GIF, WEBP, SVG</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Transform images between formats while maintaining quality and resolution.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <Video className="mb-2 h-10 w-10 text-primary" />
                  <CardTitle>Media</CardTitle>
                  <CardDescription>MP4, MP3, WAV, AVI, MOV</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Convert audio and video files with customizable quality settings.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="container py-12">
          <div className="mx-auto max-w-4xl">
            <AdBanner slot="home-page-banner" format="horizontal" className="w-full" />
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="container py-24">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold md:text-4xl">Simple, Transparent Pricing</h2>
            <p className="text-lg text-muted-foreground">Choose the plan that works best for you</p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:max-w-4xl lg:mx-auto">
            {SUBSCRIPTION_PLANS.map((plan) => (
              <Card key={plan.id} className={plan.id === "premium" ? "border-primary shadow-lg" : ""}>
                <CardHeader>
                  {plan.id === "premium" && (
                    <div className="mb-2 inline-flex w-fit rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                      Most Popular
                    </div>
                  )}
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-4xl font-bold">
                      {plan.priceInCents === 0 ? "$0" : `$${(plan.priceInCents / 100).toFixed(2)}`}
                    </span>
                    {plan.priceInCents > 0 && <span className="text-muted-foreground">/month</span>}
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-3">
                        <Check className="h-5 w-5 shrink-0 text-primary" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link href={plan.id === "free" ? "/tools" : "/auth/sign-up"} className="block">
                    <Button className="w-full" variant={plan.id === "premium" ? "default" : "outline"} size="lg">
                      {plan.id === "free" ? "Start Free" : "Upgrade to Premium"}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="border-t bg-muted/30 py-16">
          <div className="container text-center">
            <h2 className="mb-4 text-3xl font-bold">Ready to start converting?</h2>
            <p className="mb-8 text-lg text-muted-foreground">Join thousands of users converting files every day</p>
            <Link href="/auth/sign-up">
              <Button size="lg" className="gap-2">
                Get Started Free
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t py-8">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            <span className="font-semibold">ConvertPro</span>
          </div>
          <p className="text-sm text-muted-foreground">© 2025 ConvertPro. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
