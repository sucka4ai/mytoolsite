import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { ToolsClient } from "@/components/tools-client"

export default async function ToolsPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user's subscription
  const { data: subscription } = await supabase.from("subscriptions").select("*").eq("user_id", user.id).single()

  const isPremium = subscription?.plan_type === "premium"

  return <ToolsClient isPremium={isPremium} userId={user.id} />
}
